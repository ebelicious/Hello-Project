package main

import "fmt"

//M IHSAN R 1303213046
func main() {
	var gram, kgram, pon1, ons1 float64

	fmt.Scan(&gram)
	kgram = gram / 1000
	pon1 = gram / 453.592
	ons1 = gram / 28.3495
	fmt.Println(kgram, pon1, ons1)

	fmt.Scan(&gram)
	kgram = gram / 1000
	pon1 = gram / 453.592
	ons1 = gram / 28.3495
	fmt.Println(kgram, pon1, ons1)

	fmt.Scan(&gram)
	kgram = gram / 1000
	pon1 = gram / 453.592
	ons1 = gram / 28.3495
	fmt.Println(kgram, pon1, ons1)

	fmt.Scan(&gram)
	kgram = gram / 1000
	pon1 = gram / 453.592
	ons1 = gram / 28.3495
	fmt.Println(kgram, pon1, ons1)
}
