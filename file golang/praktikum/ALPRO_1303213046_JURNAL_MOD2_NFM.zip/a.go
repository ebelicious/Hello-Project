package main

import "fmt"

//1303213046_M Ihsan R
func main() {

	var s string
	var a, b int

	fmt.Scan(&s, &a, &b)
	fmt.Println("kata =", s)
	fmt.Println("Jumlah =", a+b)
}
