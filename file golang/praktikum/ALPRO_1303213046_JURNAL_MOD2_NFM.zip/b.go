package main

import "fmt"

//1303213046_M Ihsan Ramadhan
func main() {
	var luas, r float64

	fmt.Scan(&r)
	luas = r * 22 / 7
	fmt.Println(luas)
}
