package main

import (
	"bufio"
	"fmt"
	"os"
)

//M IHSAN RAMADHAN 1303213046 TP ALPRO MOD 3

func main() {
	name := bufio.NewScanner(os.Stdin)
	name.Scan()
	nama := name.Text()
	fmt.Println("Nama Saya Adalah : ", nama)
}
